package com.expensetracker.upi

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.expensetracker.upi.data.TransactionEntity
import com.expensetracker.upi.ui.dialogs.AddExpenseDialog
import com.expensetracker.upi.ui.dialogs.TransactionDetailDialog
import com.expensetracker.upi.ui.screens.*
import com.expensetracker.upi.ui.theme.ExpenseTrackerTheme
import com.expensetracker.upi.viewmodel.ExpenseViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ExpenseViewModel by viewModels()
    private var hasSmsPermission by mutableStateOf(false)

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val smsRead = permissions[Manifest.permission.READ_SMS] ?: false
        val smsReceive = permissions[Manifest.permission.RECEIVE_SMS] ?: false
        hasSmsPermission = smsRead && smsReceive

        if (hasSmsPermission) {
            viewModel.scanSmsHistory()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        checkPermissions()

        setContent {
            ExpenseTrackerTheme {
                MainAppScaffold(
                    viewModel = viewModel,
                    hasSmsPermission = hasSmsPermission,
                    onRequestPermission = { askPermissions() },
                    onOpenAppSettings = { openAppSettings() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        checkPermissions()
    }

    private fun checkPermissions() {
        val readGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
        val receiveGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
        hasSmsPermission = readGranted && receiveGranted
    }

    private fun askPermissions() {
        val perms = mutableListOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.RECEIVE_SMS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        requestPermissionLauncher.launch(perms.toTypedArray())
    }

    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
    }
}

@Composable
fun MainAppScaffold(
    viewModel: ExpenseViewModel,
    hasSmsPermission: Boolean,
    onRequestPermission: () -> Unit,
    onOpenAppSettings: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedTransaction by remember { mutableStateOf<TransactionEntity?>(null) }

    val dashboardState by viewModel.dashboardState.collectAsState()
    val transactions by viewModel.filteredTransactions.collectAsState()
    val customCategories by viewModel.customCategories.collectAsState()
    val splits by viewModel.splits.collectAsState()
    val categoryFilter by viewModel.selectedCategoryFilter.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Ruply") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.ReceiptLong, contentDescription = "Transactions") },
                    label = { Text("Spends") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Group, contentDescription = "Splits") },
                    label = { Text("Splits") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") }
                )
            }
        },
        floatingActionButton = {
            if (selectedTab != 3 && selectedTab != 2) {
                ExtendedFloatingActionButton(
                    onClick = { showAddDialog = true },
                    icon = { Icon(Icons.Default.Add, contentDescription = "Add") },
                    text = { Text("Log Spend") }
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (selectedTab) {
                0 -> DashboardScreen(
                    state = dashboardState,
                    hasSmsPermission = hasSmsPermission,
                    onPeriodSelected = { viewModel.setTimePeriod(it) },
                    onRequestPermission = onRequestPermission,
                    onScanSmsClick = { viewModel.scanSmsHistory() },
                    onTransactionClick = { selectedTransaction = it },
                    onViewAllClick = { selectedTab = 1 }
                )
                1 -> TransactionsScreen(
                    transactions = transactions,
                    selectedCategory = categoryFilter,
                    searchQuery = searchQuery,
                    onCategorySelected = { viewModel.setCategoryFilter(it) },
                    onSearchQueryChanged = { viewModel.setSearchQuery(it) },
                    onTransactionClick = { selectedTransaction = it }
                )
                2 -> SplitsScreen(
                    splits = splits,
                    onAddSplit = { name, amt, isOwed, note -> viewModel.addSplit(name, amt, isOwed, note) },
                    onSettleSplit = { viewModel.settleSplit(it) }
                )
                3 -> SettingsScreen(
                    customCategories = customCategories,
                    onAddCategory = { name, color -> viewModel.addCustomCategory(name, color) },
                    onDeleteCategory = { cat -> viewModel.deleteCustomCategory(cat) },
                    onExportCsv = { viewModel.exportToCsv() },
                    onScanSms = { days -> viewModel.scanSmsHistory(days) },
                    onOpenAppSettings = onOpenAppSettings
                )
            }
        }
    }

    if (showAddDialog) {
        AddExpenseDialog(
            onDismiss = { showAddDialog = false },
            onSave = { amount, merchant, category, mode ->
                viewModel.addManualExpense(amount, merchant, category, mode)
                showAddDialog = false
            }
        )
    }

    selectedTransaction?.let { tx ->
        TransactionDetailDialog(
            transaction = tx,
            onDismiss = { selectedTransaction = null },
            onCategoryChanged = { newCategory ->
                viewModel.updateCategory(tx, newCategory)
                selectedTransaction = null
            },
            onDelete = {
                viewModel.deleteTransaction(tx)
                selectedTransaction = null
            }
        )
    }
}
