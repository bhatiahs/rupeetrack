package com.expensetracker.upi.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.expensetracker.upi.ExpenseTrackerApp
import com.expensetracker.upi.data.CategorySpend
import com.expensetracker.upi.data.TransactionEntity
import com.expensetracker.upi.model.ExpenseCategory
import com.expensetracker.upi.model.PaymentMode
import com.expensetracker.upi.model.TransactionType
import com.expensetracker.upi.sms.SmsInboxScanner
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

data class DashboardUiState(
    val totalSpendThisMonth: Double = 0.0,
    val upiCount: Int = 0,
    val recentTransactions: List<TransactionEntity> = emptyList(),
    val categoryBreakdown: List<CategorySpend> = emptyList(),
    val isScanning: Boolean = false,
    val scannedCount: Int = 0,
    val currentMonthName: String = ""
)

class ExpenseViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as ExpenseTrackerApp).repository

    private val _isScanning = MutableStateFlow(false)
    private val _scannedCount = MutableStateFlow(0)
    private val _selectedCategoryFilter = MutableStateFlow<ExpenseCategory?>(null)
    val selectedCategoryFilter = _selectedCategoryFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val monthRange = getMonthTimeRange()

    val allTransactions: StateFlow<List<TransactionEntity>> = repository.getAllTransactions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredTransactions: StateFlow<List<TransactionEntity>> = combine(
        allTransactions,
        _selectedCategoryFilter,
        _searchQuery
    ) { transactions, category, query ->
        transactions.filter { tx ->
            val matchCategory = category == null || tx.category == category
            val matchQuery = query.isBlank() ||
                    tx.merchant.contains(query, ignoreCase = true) ||
                    (tx.vpaOrRef?.contains(query, ignoreCase = true) == true)
            matchCategory && matchQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dashboardState: StateFlow<DashboardUiState> = combine(
        repository.getTotalSpentForMonth(monthRange.first, monthRange.second),
        repository.getCategoryBreakdown(monthRange.first, monthRange.second),
        repository.getTransactionsForMonth(monthRange.first, monthRange.second),
        _isScanning,
        _scannedCount
    ) { totalSpent, breakdown, monthTransactions, isScanning, scannedCount ->
        DashboardUiState(
            totalSpendThisMonth = totalSpent ?: 0.0,
            upiCount = monthTransactions.count { it.paymentMode == PaymentMode.UPI },
            recentTransactions = monthTransactions.take(10),
            categoryBreakdown = breakdown,
            isScanning = isScanning,
            scannedCount = scannedCount,
            currentMonthName = getMonthName()
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardUiState())

    fun scanSmsHistory(daysBack: Int = 30) {
        viewModelScope.launch {
            _isScanning.value = true
            val count = SmsInboxScanner.scanExistingMessages(getApplication(), daysBack)
            _scannedCount.value = count
            _isScanning.value = false
        }
    }

    fun setCategoryFilter(category: ExpenseCategory?) {
        _selectedCategoryFilter.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateCategory(transaction: TransactionEntity, newCategory: ExpenseCategory) {
        viewModelScope.launch {
            repository.updateTransaction(transaction.copy(category = newCategory))
        }
    }

    fun addManualExpense(amount: Double, merchant: String, category: ExpenseCategory, mode: PaymentMode) {
        viewModelScope.launch {
            val entity = TransactionEntity(
                amount = amount,
                type = TransactionType.DEBIT,
                category = category,
                merchant = merchant,
                paymentMode = mode,
                timestamp = System.currentTimeMillis(),
                isAutomated = false
            )
            repository.addManualTransaction(entity)
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
        }
    }

    private fun getMonthTimeRange(): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis

        cal.add(Calendar.MONTH, 1)
        cal.add(Calendar.MILLISECOND, -1)
        val end = cal.timeInMillis
        return Pair(start, end)
    }

    private fun getMonthName(): String {
        val cal = Calendar.getInstance()
        return cal.getDisplayName(Calendar.MONTH, Calendar.LONG, java.util.Locale.getDefault()) ?: "This Month"
    }
}
