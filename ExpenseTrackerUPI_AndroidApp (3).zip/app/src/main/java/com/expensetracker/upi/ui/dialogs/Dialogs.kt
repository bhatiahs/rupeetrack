package com.expensetracker.upi.ui.dialogs

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.expensetracker.upi.data.TransactionEntity
import com.expensetracker.upi.model.ExpenseCategory
import com.expensetracker.upi.model.PaymentMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddExpenseDialog(
    onDismiss: () -> Unit,
    onSave: (amount: Double, merchant: String, category: ExpenseCategory, mode: PaymentMode) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var merchantText by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(ExpenseCategory.FOOD_DINING) }
    var selectedMode by remember { mutableStateOf(PaymentMode.UPI) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = "Add Expense", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount (₹ INR)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = merchantText,
                    onValueChange = { merchantText = it },
                    label = { Text("Paid To / Merchant") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Category", style = MaterialTheme.typography.labelLarge)
                // Dropdown or Chips
                ScrollableTabRow(
                    selectedTabIndex = ExpenseCategory.entries.indexOf(selectedCategory),
                    edgePadding = 0.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ExpenseCategory.entries.forEach { cat ->
                        Tab(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            text = { Text(cat.displayName) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (amt != null && merchantText.isNotBlank()) {
                        onSave(amt, merchantText, selectedCategory, selectedMode)
                    }
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun TransactionDetailDialog(
    transaction: TransactionEntity,
    onDismiss: () -> Unit,
    onCategoryChanged: (ExpenseCategory) -> Unit,
    onDelete: () -> Unit
) {
    var showCategoryPicker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = transaction.merchant, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Amount: ₹${"%.2f".format(transaction.amount)}", style = MaterialTheme.typography.titleMedium)
                Text("Payment Mode: ${transaction.paymentMode.name}", style = MaterialTheme.typography.bodyMedium)
                if (!transaction.vpaOrRef.isNullOrBlank()) {
                    Text("Ref / UPI: ${transaction.vpaOrRef}", style = MaterialTheme.typography.bodySmall)
                }
                if (!transaction.accountInfo.isNullOrBlank()) {
                    Text("Account: ${transaction.accountInfo}", style = MaterialTheme.typography.bodySmall)
                }

                Spacer(modifier = Modifier.height(4.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(4.dp))

                Text("Current Category: ${transaction.category.displayName}", fontWeight = FontWeight.SemiBold)
                Button(
                    onClick = { showCategoryPicker = !showCategoryPicker },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Text("Change Category", color = MaterialTheme.colorScheme.onSecondaryContainer)
                }

                if (showCategoryPicker) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        ExpenseCategory.entries.forEach { cat ->
                            Text(
                                text = cat.displayName,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onCategoryChanged(cat)
                                        showCategoryPicker = false
                                    }
                                    .padding(vertical = 8.dp),
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }

                if (!transaction.rawSms.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Original SMS:", style = MaterialTheme.typography.labelSmall)
                    Text(
                        text = transaction.rawSms,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        },
        dismissButton = {
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
            }
        }
    )
}
