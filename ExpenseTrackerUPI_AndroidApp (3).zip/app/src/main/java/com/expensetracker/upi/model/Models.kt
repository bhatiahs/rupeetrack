package com.expensetracker.upi.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class TransactionType {
    DEBIT,
    CREDIT
}

enum class PaymentMode {
    UPI,
    CARD,
    NET_BANKING,
    CASH,
    OTHER
}

enum class ExpenseCategory(
    val displayName: String,
    val icon: ImageVector,
    val color: Color
) {
    FOOD_DINING("Food & Dining", Icons.Default.Restaurant, Color(0xFFEF5350)),
    GROCERY("Groceries & Daily", Icons.Default.LocalGroceryStore, Color(0xFF4CAF50)),
    SHOPPING("Shopping & E-Commerce", Icons.Default.ShoppingBag, Color(0xFFFF9800)),
    TRAVEL_COMMUTE("Travel & Fuel", Icons.Default.DirectionsCar, Color(0xFF03A9F4)),
    BILLS_UTILITIES("Bills & Utilities", Icons.Default.ReceiptLong, Color(0xFF9C27B0)),
    ENTERTAINMENT("Entertainment", Icons.Default.Movie, Color(0xFFE91E63)),
    HEALTH_WELLNESS("Health & Medical", Icons.Default.MedicalServices, Color(0xFF009688)),
    INVESTMENT_TRANSFER("Transfers & Self", Icons.Default.AccountBalance, Color(0xFF3F51B5)),
    UNCATEGORIZED("General UPI", Icons.Default.Payments, Color(0xFF78909C));

    companion object {
        fun fromString(value: String): ExpenseCategory {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: UNCATEGORIZED
        }
    }
}

data class ParsedTransaction(
    val amount: Double,
    val type: TransactionType,
    val merchant: String,
    val category: ExpenseCategory,
    val paymentMode: PaymentMode = PaymentMode.UPI,
    val vpaOrRef: String? = null,
    val accountInfo: String? = null,
    val date: Long = System.currentTimeMillis(),
    val rawSms: String,
    val sender: String
)
