package com.expensetracker.upi.sms

import android.content.Context
import android.provider.Telephony
import com.expensetracker.upi.ExpenseTrackerApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object SmsInboxScanner {

    suspend fun scanExistingMessages(context: Context, daysBack: Int = 30): Int = withContext(Dispatchers.IO) {
        val repository = ExpenseTrackerApp.instance.repository
        var count = 0

        val cutoffTime = System.currentTimeMillis() - (daysBack.toLong() * 24 * 60 * 60 * 1000)
        val uri = Telephony.Sms.Inbox.CONTENT_URI
        val projection = arrayOf(
            Telephony.Sms.Inbox.ADDRESS,
            Telephony.Sms.Inbox.BODY,
            Telephony.Sms.Inbox.DATE
        )
        val selection = "${Telephony.Sms.Inbox.DATE} >= ?"
        val selectionArgs = arrayOf(cutoffTime.toString())

        context.contentResolver.query(uri, projection, selection, selectionArgs, "${Telephony.Sms.Inbox.DATE} DESC")?.use { cursor ->
            val addressIndex = cursor.getColumnIndex(Telephony.Sms.Inbox.ADDRESS)
            val bodyIndex = cursor.getColumnIndex(Telephony.Sms.Inbox.BODY)
            val dateIndex = cursor.getColumnIndex(Telephony.Sms.Inbox.DATE)

            while (cursor.moveToNext()) {
                val sender = cursor.getString(addressIndex) ?: ""
                val body = cursor.getString(bodyIndex) ?: ""
                val date = cursor.getLong(dateIndex)

                val parsed = SmsParser.parse(body, sender, date)
                if (parsed != null) {
                    val saved = repository.saveParsedTransaction(parsed)
                    if (saved) count++
                }
            }
        }
        count
    }
}
