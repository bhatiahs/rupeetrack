package com.expensetracker.upi.sms

import com.expensetracker.upi.model.ParsedTransaction
import com.expensetracker.upi.model.PaymentMode
import com.expensetracker.upi.model.TransactionType
import java.util.regex.Pattern

object SmsParser {

    // Regex for Indian currency amounts: Rs. 500, Rs 500.50, INR 1,234.00, Rs.1200
    private val amountPattern = Pattern.compile(
        """(?:(?:rs\.?|inr)\s*([\d,]+(?:\.\d{1,2})?)|([\d,]+(?:\.\d{1,2})?)\s*(?:rs\.?|inr))""",
        Pattern.CASE_INSENSITIVE
    )

    // Strict debit keywords indicating actual deduction of money
    private val debitKeywords = listOf(
        "debited", "was debited", "is debited", "has been debited",
        "paid rs", "spent rs", "sent rs", "transferred to", "vpa",
        "withdrawn", "charged to"
    )

    // Credit / refund keywords
    private val creditKeywords = listOf("credited", "received", "refunded", "cashback")

    // False-positive phrases: bill reminders, due notices, OTPs, promotional alerts
    private val ignorePatterns = listOf(
        """\bdue\s+date\b""",
        """\bdue\s+on\b""",
        """\bis\s+due\b""",
        """\bbill\s+(?:is\s+)?generated\b""",
        """\bbill\s+of\s+(?:rs\.?|inr)\b""",
        """\bmin(?:imum)?\s+amount\s+due\b""",
        """\btotal\s+amount\s+due\b""",
        """\bpay\s+before\b""",
        """\bpay\s+by\b""",
        """\bpay\s+now\b""",
        """\bpayment\s+reminder\b""",
        """\bbill\s+reminder\b""",
        """\breminder:?\b""",
        """\botp\b""",
        """\bone\s*time\s*password\b""",
        """\bverification\s*code\b""",
        """\bdo\s+not\s+share\b""",
        """\bcollect\s+request\b""",
        """\bhas\s+requested\b""",
        """\bpre-?approved\b""",
        """\bapply\s+now\b"""
    ).map { Pattern.compile(it, Pattern.CASE_INSENSITIVE) }

    // Bank / UPI Ref regex
    private val refPattern = Pattern.compile(
        """(?:ref\s*(?:no\.?)?|utr|txn\s*id|upi\s*ref)\s*[:\-]?\s*([A-Za-z0-9]+)""",
        Pattern.CASE_INSENSITIVE
    )

    // VPA / UPI ID pattern: user@upi, shop@okhdfcbank, name@ybl
    private val vpaPattern = Pattern.compile(
        """([a-zA-Z0-9.\-_]+@[a-zA-Z0-9]+)""",
        Pattern.CASE_INSENSITIVE
    )

    // Payee / Merchant extraction patterns
    private val merchantPatterns = listOf(
        Pattern.compile("""(?:to|towards|at|paid to|vpa)\s+([A-Za-z0-9\s&.'\-]{2,30}?)(?:\s+on|\s+ref|\s+upi|\s+avl|\s+bal|\s+dated|\.|,|$)""", Pattern.CASE_INSENSITIVE),
        Pattern.compile("""transfer\s+to\s+([A-Za-z0-9\s&.'\-]{2,30}?)(?:\s+ref|\s+on|\.|,|$)""", Pattern.CASE_INSENSITIVE)
    )

    // Account ending pattern: A/c XX1234 or ending 1234
    private val accountPattern = Pattern.compile(
        """(?:a/c|acct|card|ending|xx)\s*([xX]*\d{3,4})""",
        Pattern.CASE_INSENSITIVE
    )

    fun parse(smsBody: String, sender: String, timestamp: Long = System.currentTimeMillis()): ParsedTransaction? {
        val lowerText = smsBody.lowercase()

        // 1. Filter out OTPs and verification messages immediately
        if (lowerText.contains("otp") || lowerText.contains("verification code") || lowerText.contains("one time password")) {
            return null
        }

        // 2. Filter out bill reminders and due notices
        val isBillReminder = ignorePatterns.any { it.matcher(smsBody).find() }
        val hasExplicitAccountDebit = lowerText.contains("debited") || lowerText.contains("was debited") || lowerText.contains("is debited")

        // If it's a bill reminder and NOT an explicit debit confirmation, skip it
        if (isBillReminder && !hasExplicitAccountDebit) {
            return null
        }

        // 3. Determine Debit vs Credit
        val isDebit = debitKeywords.any { lowerText.contains(it) }
        val isCredit = creditKeywords.any { lowerText.contains(it) }

        if (!isDebit && !isCredit) return null
        val type = if (isDebit) TransactionType.DEBIT else TransactionType.CREDIT

        // 4. Extract Amount
        val amountMatcher = amountPattern.matcher(smsBody)
        var amount: Double? = null
        if (amountMatcher.find()) {
            val amtStr = (amountMatcher.group(1) ?: amountMatcher.group(2))?.replace(",", "")
            amount = amtStr?.toDoubleOrNull()
        }
        if (amount == null || amount <= 0.0) return null

        // 5. Extract Ref / UTR
        val refMatcher = refPattern.matcher(smsBody)
        val refNo = if (refMatcher.find()) refMatcher.group(1) else null

        // 6. Extract VPA (UPI ID)
        val vpaMatcher = vpaPattern.matcher(smsBody)
        val vpa = if (vpaMatcher.find()) vpaMatcher.group(1) else null

        // 7. Extract Merchant / Payee
        var merchant: String? = null
        for (pattern in merchantPatterns) {
            val m = pattern.matcher(smsBody)
            if (m.find()) {
                val candidate = m.group(1)?.trim()
                if (!candidate.isNullOrBlank() && !candidate.equals("vpa", ignoreCase = true) && candidate.length > 1) {
                    merchant = candidate
                    break
                }
            }
        }

        if (merchant.isNullOrBlank()) {
            merchant = vpa ?: if (lowerText.contains("upi")) "UPI Transaction" else "Bank Transaction"
        }

        // Clean up merchant name (remove app prefixes/suffixes)
        merchant = merchant.replace(Regex("""(?i)\bvia\s+(phonepe|google\s*pay|gpay|paytm|cred|bhim|upi)\b"""), "").trim()
        merchant = merchant.replace(Regex("""(?i)\b(upi|ref|bal|avl|on|dated|dr|cr)\b"""), "").trim()
        if (merchant.isBlank()) merchant = "UPI Transfer"

        // 8. Extract Account info
        val accMatcher = accountPattern.matcher(smsBody)
        val account = if (accMatcher.find()) accMatcher.group(1) else null

        // 9. Payment Mode
        val mode = if (lowerText.contains("upi") || vpa != null) {
            PaymentMode.UPI
        } else if (lowerText.contains("card")) {
            PaymentMode.CARD
        } else if (lowerText.contains("netbanking") || lowerText.contains("neft") || lowerText.contains("imps")) {
            PaymentMode.NET_BANKING
        } else {
            PaymentMode.UPI
        }

        // 10. Auto-categorize
        val category = CategoryClassifier.classify(merchant, smsBody, vpa)

        return ParsedTransaction(
            amount = amount,
            type = type,
            merchant = merchant.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() },
            category = category,
            paymentMode = mode,
            vpaOrRef = refNo ?: vpa,
            accountInfo = account,
            date = timestamp,
            rawSms = smsBody,
            sender = sender
        )
    }
}
