package com.expensetracker.upi.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.expensetracker.upi.ExpenseTrackerApp
import com.expensetracker.upi.data.CategorySpend
import com.expensetracker.upi.data.CustomCategoryEntity
import com.expensetracker.upi.data.TransactionEntity
import com.expensetracker.upi.export.CsvExporter
import com.expensetracker.upi.model.ExpenseCategory
import com.expensetracker.upi.model.PaymentMode
import com.expensetracker.upi.model.TransactionType
import com.expensetracker.upi.sms.SmsInboxScanner
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class TimePeriod(val title: String) {
    WEEK("Week"),
    MONTH("Month"),
    YEAR("Year")
}

data class ChartBarData(
    val label: String,
    val amount: Double,
    val isHighlighted: Boolean = false
)

data class DashboardUiState(
    val totalSpend: Double = 0.0,
    val upiCount: Int = 0,
    val avgPerDay: Double = 0.0,
    val recentTransactions: List<TransactionEntity> = emptyList(),
    val categoryBreakdown: List<CategorySpend> = emptyList(),
    val chartBars: List<ChartBarData> = emptyList(),
    val isScanning: Boolean = false,
    val scannedCount: Int = 0,
    val selectedPeriod: TimePeriod = TimePeriod.MONTH,
    val periodLabel: String = ""
) {
    val totalSpendThisMonth: Double get() = totalSpend
    val currentMonthName: String get() = periodLabel
}

class ExpenseViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as ExpenseTrackerApp).repository

    private val _selectedPeriod = MutableStateFlow(TimePeriod.MONTH)
    val selectedPeriod = _selectedPeriod.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    private val _scannedCount = MutableStateFlow(0)
    private val _selectedCategoryFilter = MutableStateFlow<ExpenseCategory?>(null)
    val selectedCategoryFilter = _selectedCategoryFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    val allTransactions: StateFlow<List<TransactionEntity>> = repository.getAllTransactions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customCategories: StateFlow<List<CustomCategoryEntity>> = repository.getAllCustomCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredTransactions: StateFlow<List<TransactionEntity>> = combine(
        allTransactions,
        _selectedCategoryFilter,
        _searchQuery
    ) { transactions, category, query ->
        transactions.filter { tx ->
            val matchCategory = category == null || tx.category == category
            val matchQuery = query.isBlank() ||
                    tx.merchant.contains(query, ignoreCase = true) ||
                    (tx.vpaOrRef?.contains(query, ignoreCase = true) == true)
            matchCategory && matchQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dashboardState: StateFlow<DashboardUiState> = combine(
        allTransactions,
        _selectedPeriod,
        _isScanning,
        _scannedCount
    ) { transactions, period, isScanning, scannedCount ->
        val range = getTimeRange(period)
        val periodTx = transactions.filter { it.timestamp in range.first..range.second && it.type == TransactionType.DEBIT }

        val total = periodTx.sumOf { it.amount }
        val upiTotalCount = periodTx.count { it.paymentMode == PaymentMode.UPI }

        val daysCount = when (period) {
            TimePeriod.WEEK -> 7
            TimePeriod.MONTH -> Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH)
            TimePeriod.YEAR -> 365
        }
        val avg = if (daysCount > 0) total / daysCount else 0.0

        val categoryGroups = periodTx.groupBy { it.category }
            .map { (cat, list) -> CategorySpend(cat, list.sumOf { it.amount }, list.size) }
            .sortedByDescending { it.totalAmount }

        val chartBars = generateChartBars(period, periodTx)

        DashboardUiState(
            totalSpend = total,
            upiCount = upiTotalCount,
            avgPerDay = avg,
            recentTransactions = periodTx.take(8),
            categoryBreakdown = categoryGroups,
            chartBars = chartBars,
            isScanning = isScanning,
            scannedCount = scannedCount,
            selectedPeriod = period,
            periodLabel = getPeriodLabel(period)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardUiState())

    fun setTimePeriod(period: TimePeriod) {
        _selectedPeriod.value = period
    }

    fun scanSmsHistory(daysBack: Int = 30) {
        viewModelScope.launch {
            _isScanning.value = true
            val count = SmsInboxScanner.scanExistingMessages(getApplication(), daysBack)
            _scannedCount.value = count
            _isScanning.value = false
        }
    }

    fun setCategoryFilter(category: ExpenseCategory?) {
        _selectedCategoryFilter.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateCategory(transaction: TransactionEntity, newCategory: ExpenseCategory) {
        viewModelScope.launch {
            repository.updateTransaction(transaction.copy(category = newCategory))
        }
    }

    fun addCustomCategory(name: String, colorHex: String) {
        viewModelScope.launch {
            repository.addCustomCategory(name, colorHex)
        }
    }

    fun deleteCustomCategory(category: CustomCategoryEntity) {
        viewModelScope.launch {
            repository.deleteCustomCategory(category)
        }
    }

    fun addManualExpense(amount: Double, merchant: String, category: ExpenseCategory, mode: PaymentMode) {
        viewModelScope.launch {
            val entity = TransactionEntity(
                amount = amount,
                type = TransactionType.DEBIT,
                category = category,
                merchant = merchant,
                paymentMode = mode,
                timestamp = System.currentTimeMillis(),
                isAutomated = false
            )
            repository.addManualTransaction(entity)
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
        }
    }

    fun exportToCsv() {
        viewModelScope.launch {
            val list = repository.getAllTransactionsSync()
            CsvExporter.generateAndShareCsv(getApplication(), list)
        }
    }

    private fun getTimeRange(period: TimePeriod): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)

        return when (period) {
            TimePeriod.WEEK -> {
                cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
                val start = cal.timeInMillis
                cal.add(Calendar.DAY_OF_WEEK, 7)
                cal.add(Calendar.MILLISECOND, -1)
                Pair(start, cal.timeInMillis)
            }
            TimePeriod.MONTH -> {
                cal.set(Calendar.DAY_OF_MONTH, 1)
                val start = cal.timeInMillis
                cal.add(Calendar.MONTH, 1)
                cal.add(Calendar.MILLISECOND, -1)
                Pair(start, cal.timeInMillis)
            }
            TimePeriod.YEAR -> {
                cal.set(Calendar.DAY_OF_YEAR, 1)
                val start = cal.timeInMillis
                cal.add(Calendar.YEAR, 1)
                cal.add(Calendar.MILLISECOND, -1)
                Pair(start, cal.timeInMillis)
            }
        }
    }

    private fun getPeriodLabel(period: TimePeriod): String {
        val cal = Calendar.getInstance()
        return when (period) {
            TimePeriod.WEEK -> "This Week"
            TimePeriod.MONTH -> cal.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault()) ?: "This Month"
            TimePeriod.YEAR -> cal.get(Calendar.YEAR).toString()
        }
    }

    private fun generateChartBars(period: TimePeriod, transactions: List<TransactionEntity>): List<ChartBarData> {
        val cal = Calendar.getInstance()
        val currentDayOrMonth = when (period) {
            TimePeriod.WEEK -> cal.get(Calendar.DAY_OF_WEEK)
            TimePeriod.MONTH -> cal.get(Calendar.WEEK_OF_MONTH)
            TimePeriod.YEAR -> cal.get(Calendar.MONTH)
        }

        return when (period) {
            TimePeriod.WEEK -> {
                val days = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
                days.mapIndexed { idx, label ->
                    val dayOfWeek = idx + 1
                    val sum = transactions.filter {
                        val c = Calendar.getInstance().apply { timeInMillis = it.timestamp }
                        c.get(Calendar.DAY_OF_WEEK) == dayOfWeek
                    }.sumOf { it.amount }
                    ChartBarData(label, sum, isHighlighted = (dayOfWeek == currentDayOrMonth))
                }
            }
            TimePeriod.MONTH -> {
                val weeks = listOf("W1", "W2", "W3", "W4", "W5")
                weeks.mapIndexed { idx, label ->
                    val weekIdx = idx + 1
                    val sum = transactions.filter {
                        val c = Calendar.getInstance().apply { timeInMillis = it.timestamp }
                        c.get(Calendar.WEEK_OF_MONTH) == weekIdx
                    }.sumOf { it.amount }
                    ChartBarData(label, sum, isHighlighted = (weekIdx == currentDayOrMonth))
                }
            }
            TimePeriod.YEAR -> {
                val months = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
                months.mapIndexed { idx, label ->
                    val sum = transactions.filter {
                        val c = Calendar.getInstance().apply { timeInMillis = it.timestamp }
                        c.get(Calendar.MONTH) == idx
                    }.sumOf { it.amount }
                    ChartBarData(label, sum, isHighlighted = (idx == currentDayOrMonth))
                }
            }
        }
    }
}
