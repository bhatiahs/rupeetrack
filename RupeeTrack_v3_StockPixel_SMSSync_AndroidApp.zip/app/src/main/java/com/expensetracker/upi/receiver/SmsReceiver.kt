package com.expensetracker.upi.receiver

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import androidx.core.app.NotificationCompat
import com.expensetracker.upi.ExpenseTrackerApp
import com.expensetracker.upi.MainActivity
import com.expensetracker.upi.R
import com.expensetracker.upi.sms.SmsParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val repository = ExpenseTrackerApp.instance.repository

        for (sms in messages) {
            val sender = sms.displayOriginatingAddress ?: continue
            val body = sms.displayMessageBody ?: continue
            val timestamp = sms.timestampMillis

            // Check if SMS looks like financial message from a bank/payment service
            // Usually 6-8 chars like AD-HDFCBK, VM-SBIINB, BZ-PAYTM, AX-KOTAKB
            val parsed = SmsParser.parse(body, sender, timestamp) ?: continue

            CoroutineScope(Dispatchers.IO).launch {
                val saved = repository.saveParsedTransaction(parsed)
                if (saved) {
                    showTransactionNotification(context, parsed.amount, parsed.merchant, parsed.category.displayName)
                }
            }
        }
    }

    private fun showTransactionNotification(context: Context, amount: Double, merchant: String, category: String) {
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(context, ExpenseTrackerApp.CHANNEL_ID_EXPENSES)
            .setSmallIcon(android.R.drawable.ic_menu_agenda)
            .setContentTitle("UPI Spend Detected: ₹${"%.2f".format(amount)}")
            .setContentText("$merchant • Categorized as $category")
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(System.currentTimeMillis().toInt(), notification)
    }
}
