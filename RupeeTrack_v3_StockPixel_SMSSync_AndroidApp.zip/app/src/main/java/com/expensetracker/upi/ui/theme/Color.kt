package com.expensetracker.upi.ui.theme

import androidx.compose.ui.graphics.Color

// Pixel Material You Fallback Tonal Palette
val PixelPrimaryLight = Color(0xFF1E6586)
val PixelOnPrimaryLight = Color(0xFFFFFFFF)
val PixelPrimaryContainerLight = Color(0xFFC3E8FF)
val PixelOnPrimaryContainerLight = Color(0xFF001E2C)

val PixelSecondaryLight = Color(0xFF4E616D)
val PixelOnSecondaryLight = Color(0xFFFFFFFF)
val PixelSecondaryContainerLight = Color(0xFFD1E5F4)
val PixelOnSecondaryContainerLight = Color(0xFF0B1D28)

val PixelTertiaryLight = Color(0xFF605A7D)
val PixelOnTertiaryLight = Color(0xFFFFFFFF)
val PixelTertiaryContainerLight = Color(0xFFE6DEFF)
val PixelOnTertiaryContainerLight = Color(0xFF1D1736)

val PixelBackgroundLight = Color(0xFFFBFCFE)
val PixelOnBackgroundLight = Color(0xFF191C1E)
val PixelSurfaceLight = Color(0xFFFBFCFE)
val PixelOnSurfaceLight = Color(0xFF191C1E)
val PixelSurfaceVariantLight = Color(0xFFDCE3E9)
val PixelOnSurfaceVariantLight = Color(0xFF40484C)

// Dark Theme Palette
val PixelPrimaryDark = Color(0xFF8DCDFF)
val PixelOnPrimaryDark = Color(0xFF00344A)
val PixelPrimaryContainerDark = Color(0xFF004C6A)
val PixelOnPrimaryContainerDark = Color(0xFFC3E8FF)

val PixelSecondaryDark = Color(0xFFB5C9D7)
val PixelOnSecondaryDark = Color(0xFF20333E)
val PixelSecondaryContainerDark = Color(0xFF374955)
val PixelOnSecondaryContainerDark = Color(0xFFD1E5F4)

val PixelBackgroundDark = Color(0xFF111415)
val PixelOnBackgroundDark = Color(0xFFE1E2E5)
val PixelSurfaceDark = Color(0xFF111415)
val PixelOnSurfaceDark = Color(0xFFE1E2E5)
val PixelSurfaceVariantDark = Color(0xFF40484C)
val PixelOnSurfaceVariantDark = Color(0xFFC0C7CD)
