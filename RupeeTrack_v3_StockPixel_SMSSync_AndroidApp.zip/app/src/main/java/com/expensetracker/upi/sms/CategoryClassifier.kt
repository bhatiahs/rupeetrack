package com.expensetracker.upi.sms

import com.expensetracker.upi.model.ExpenseCategory

object CategoryClassifier {

    private val foodKeywords = listOf(
        "swiggy", "zomato", "mcdonald", "domino", "starbucks", "kfc", "burger king",
        "chai", "tea", "cafe", "restaurant", "dine", "biryani", "pizza", "bakery",
        "eatclub", "behrouz", "faasos", "subway", "haldiram", "barbeque nation"
    )

    private val groceryKeywords = listOf(
        "blinkit", "zepto", "instamart", "bigbasket", "bb daily", "dmart", "d-mart",
        "spencer", "reliance fresh", "reliance smart", "nature basket", "milk", "kirana",
        "supermarket", "super market", "provision", "organic", "vegetable", "fruits", "more retail"
    )

    private val shoppingKeywords = listOf(
        "amazon", "flipkart", "myntra", "ajio", "meesho", "nykaa", "zara", "h&m",
        "decathlon", "tata cliq", "croma", "reliance digital", "vijay sales", "lenskart",
        "uniquo", "westside", "pantaloons", "max fashion", "shoppers stop"
    )

    private val travelKeywords = listOf(
        "uber", "ola", "rapido", "irctc", "makemytrip", "goibibo", "redbus", "cleartrip",
        "indianoil", "ioc", "bpcl", "bharat petroleum", "hpcl", "hindustan petroleum",
        "shell", "petrol", "fuel", "cng", "toll", "fastag", "metro", "auto", "airline", "indigo"
    )

    private val utilityKeywords = listOf(
        "electricity", "power", "bescom", "tneb", "mahavitaran", "cesc", "water",
        "gas", "adani gas", "indraprastha", "mahanagar gas", "airtel", "jio", "vi", "vodafone",
        "bsnl", "broadband", "act fibernet", "wifi", "recharge", "billdesk", "tatapower"
    )

    private val entertainmentKeywords = listOf(
        "netflix", "spotify", "hotstar", "disney", "prime video", "amazon prime",
        "youtube", "apple.com", "google play", "playstore", "bookmyshow", "pvr", "inox", "cinema"
    )

    private val healthKeywords = listOf(
        "pharmacy", "apollo", "1mg", "pharmeasy", "medplus", "netmeds", "clinic",
        "hospital", "doctor", "dental", "diagnostics", "pathology", "cult.fit", "gym", "fitness"
    )

    private val transferKeywords = listOf(
        "mutual fund", "zerodha", "groww", "kuvera", "upstox", "angelone", "indmoney",
        "lic", "insurance", "savings", "fd", "deposit"
    )

    fun classify(merchant: String, rawText: String, vpa: String?): ExpenseCategory {
        val combined = "$merchant $rawText ${vpa ?: ""}".lowercase()

        // Prioritize grocery & food detection common in UPI
        if (groceryKeywords.any { combined.contains(it) }) return ExpenseCategory.GROCERY
        if (foodKeywords.any { combined.contains(it) }) return ExpenseCategory.FOOD_DINING
        if (travelKeywords.any { combined.contains(it) }) return ExpenseCategory.TRAVEL_COMMUTE
        if (shoppingKeywords.any { combined.contains(it) }) return ExpenseCategory.SHOPPING
        if (utilityKeywords.any { combined.contains(it) }) return ExpenseCategory.BILLS_UTILITIES
        if (entertainmentKeywords.any { combined.contains(it) }) return ExpenseCategory.ENTERTAINMENT
        if (healthKeywords.any { combined.contains(it) }) return ExpenseCategory.HEALTH_WELLNESS
        if (transferKeywords.any { combined.contains(it) }) return ExpenseCategory.INVESTMENT_TRANSFER

        return ExpenseCategory.UNCATEGORIZED
    }
}
