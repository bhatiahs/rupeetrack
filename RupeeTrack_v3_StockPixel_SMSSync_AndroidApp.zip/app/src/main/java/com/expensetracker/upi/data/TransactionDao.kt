package com.expensetracker.upi.data

import androidx.room.*
import com.expensetracker.upi.model.ExpenseCategory
import kotlinx.coroutines.flow.Flow

data class CategorySpend(
    val category: ExpenseCategory,
    val totalAmount: Double,
    val count: Int
)

data class TimeSeriesSpend(
    val periodLabel: String,
    val totalAmount: Double
)

@Dao
interface TransactionDao {

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE timestamp BETWEEN :startTime AND :endTime ORDER BY timestamp DESC")
    fun getTransactionsBetween(startTime: Long, endTime: Long): Flow<List<TransactionEntity>>

    @Query("""
        SELECT category, SUM(amount) as totalAmount, COUNT(id) as count 
        FROM transactions 
        WHERE type = 'DEBIT' AND timestamp BETWEEN :startTime AND :endTime 
        GROUP BY category 
        ORDER BY totalAmount DESC
    """)
    fun getCategoryBreakdown(startTime: Long, endTime: Long): Flow<List<CategorySpend>>

    @Query("""
        SELECT SUM(amount) FROM transactions 
        WHERE type = 'DEBIT' AND timestamp BETWEEN :startTime AND :endTime
    """)
    fun getTotalSpentBetween(startTime: Long, endTime: Long): Flow<Double?>

    @Query("SELECT * FROM transactions WHERE vpaOrRef = :ref LIMIT 1")
    suspend fun getTransactionByRef(ref: String): TransactionEntity?

    @Query("SELECT * FROM transactions WHERE amount = :amount AND timestamp BETWEEN :minTime AND :maxTime LIMIT 1")
    suspend fun findDuplicate(amount: Double, minTime: Long, maxTime: Long): TransactionEntity?

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    suspend fun getAllTransactionsSync(): List<TransactionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transaction: TransactionEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(transactions: List<TransactionEntity>): List<Long>

    @Update
    suspend fun update(transaction: TransactionEntity)

    @Delete
    suspend fun delete(transaction: TransactionEntity)

    // Custom Categories
    @Query("SELECT * FROM custom_categories ORDER BY name ASC")
    fun getAllCustomCategories(): Flow<List<CustomCategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomCategory(category: CustomCategoryEntity): Long

    @Delete
    suspend fun deleteCustomCategory(category: CustomCategoryEntity)
}
