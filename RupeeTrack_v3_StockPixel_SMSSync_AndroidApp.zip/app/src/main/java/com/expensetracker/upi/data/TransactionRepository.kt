package com.expensetracker.upi.data

import com.expensetracker.upi.model.ParsedTransaction
import kotlinx.coroutines.flow.Flow

class TransactionRepository(private val dao: TransactionDao) {

    fun getAllTransactions(): Flow<List<TransactionEntity>> = dao.getAllTransactions()

    fun getTransactionsBetween(startTime: Long, endTime: Long): Flow<List<TransactionEntity>> =
        dao.getTransactionsBetween(startTime, endTime)

    fun getCategoryBreakdown(startTime: Long, endTime: Long): Flow<List<CategorySpend>> =
        dao.getCategoryBreakdown(startTime, endTime)

    fun getTotalSpentBetween(startTime: Long, endTime: Long): Flow<Double?> =
        dao.getTotalSpentBetween(startTime, endTime)

    suspend fun getAllTransactionsSync(): List<TransactionEntity> = dao.getAllTransactionsSync()

    suspend fun saveParsedTransaction(parsed: ParsedTransaction): Boolean {
        if (!parsed.vpaOrRef.isNullOrBlank()) {
            val existing = dao.getTransactionByRef(parsed.vpaOrRef)
            if (existing != null) return false
        }

        val window = 120_000L
        val duplicate = dao.findDuplicate(parsed.amount, parsed.date - window, parsed.date + window)
        if (duplicate != null && duplicate.merchant.equals(parsed.merchant, ignoreCase = true)) {
            return false
        }

        val entity = TransactionEntity(
            amount = parsed.amount,
            type = parsed.type,
            category = parsed.category,
            merchant = parsed.merchant,
            paymentMode = parsed.paymentMode,
            vpaOrRef = parsed.vpaOrRef,
            accountInfo = parsed.accountInfo,
            timestamp = parsed.date,
            rawSms = parsed.rawSms,
            sender = parsed.sender,
            isAutomated = true
        )
        dao.insert(entity)
        return true
    }

    suspend fun addManualTransaction(entity: TransactionEntity) {
        dao.insert(entity)
    }

    suspend fun updateTransaction(entity: TransactionEntity) {
        dao.update(entity)
    }

    suspend fun deleteTransaction(entity: TransactionEntity) {
        dao.delete(entity)
    }

    // Custom Categories
    fun getAllCustomCategories(): Flow<List<CustomCategoryEntity>> = dao.getAllCustomCategories()

    suspend fun addCustomCategory(name: String, colorHex: String) {
        dao.insertCustomCategory(CustomCategoryEntity(name = name, colorHex = colorHex))
    }

    suspend fun deleteCustomCategory(category: CustomCategoryEntity) {
        dao.deleteCustomCategory(category)
    }
}
