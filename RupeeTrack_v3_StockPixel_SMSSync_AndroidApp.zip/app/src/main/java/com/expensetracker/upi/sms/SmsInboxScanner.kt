package com.expensetracker.upi.sms

import android.content.Context
import android.provider.Telephony
import com.expensetracker.upi.ExpenseTrackerApp
import com.expensetracker.upi.data.TransactionEntity
import com.expensetracker.upi.model.RawSmsItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs

object SmsInboxScanner {

    suspend fun scanExistingMessages(context: Context, daysBack: Int = 60): Int = withContext(Dispatchers.IO) {
        val repository = ExpenseTrackerApp.instance.repository
        var count = 0

        val cutoffTime = System.currentTimeMillis() - (daysBack.toLong() * 24 * 60 * 60 * 1000)
        val uri = Telephony.Sms.Inbox.CONTENT_URI
        val projection = arrayOf(
            Telephony.Sms.Inbox._ID,
            Telephony.Sms.Inbox.ADDRESS,
            Telephony.Sms.Inbox.BODY,
            Telephony.Sms.Inbox.DATE
        )
        val selection = "${Telephony.Sms.Inbox.DATE} >= ?"
        val selectionArgs = arrayOf(cutoffTime.toString())

        try {
            context.contentResolver.query(
                uri,
                projection,
                selection,
                selectionArgs,
                "${Telephony.Sms.Inbox.DATE} DESC"
            )?.use { cursor ->
                val addressIndex = cursor.getColumnIndex(Telephony.Sms.Inbox.ADDRESS)
                val bodyIndex = cursor.getColumnIndex(Telephony.Sms.Inbox.BODY)
                val dateIndex = cursor.getColumnIndex(Telephony.Sms.Inbox.DATE)

                while (cursor.moveToNext()) {
                    val sender = if (addressIndex >= 0) cursor.getString(addressIndex) ?: "" else ""
                    val body = if (bodyIndex >= 0) cursor.getString(bodyIndex) ?: "" else ""
                    val date = if (dateIndex >= 0) cursor.getLong(dateIndex) else System.currentTimeMillis()

                    val parsed = SmsParser.parse(body, sender, date)
                    if (parsed != null) {
                        val saved = repository.saveParsedTransaction(parsed)
                        if (saved) count++
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        count
    }

    /**
     * Loads SMS messages from the device inbox and cross-references them against synced transactions
     * in Room DB so the user can see which messages are Synced vs Not Synced.
     */
    suspend fun loadInboxForInspection(
        context: Context,
        existingTransactions: List<TransactionEntity>,
        daysBack: Int = 60,
        maxMessages: Int = 200
    ): List<RawSmsItem> = withContext(Dispatchers.IO) {
        val result = mutableListOf<RawSmsItem>()
        val cutoffTime = System.currentTimeMillis() - (daysBack.toLong() * 24 * 60 * 60 * 1000)
        val uri = Telephony.Sms.Inbox.CONTENT_URI
        val projection = arrayOf(
            Telephony.Sms.Inbox._ID,
            Telephony.Sms.Inbox.ADDRESS,
            Telephony.Sms.Inbox.BODY,
            Telephony.Sms.Inbox.DATE
        )
        val selection = "${Telephony.Sms.Inbox.DATE} >= ?"
        val selectionArgs = arrayOf(cutoffTime.toString())

        try {
            context.contentResolver.query(
                uri,
                projection,
                selection,
                selectionArgs,
                "${Telephony.Sms.Inbox.DATE} DESC"
            )?.use { cursor ->
                val idIndex = cursor.getColumnIndex(Telephony.Sms.Inbox._ID)
                val addressIndex = cursor.getColumnIndex(Telephony.Sms.Inbox.ADDRESS)
                val bodyIndex = cursor.getColumnIndex(Telephony.Sms.Inbox.BODY)
                val dateIndex = cursor.getColumnIndex(Telephony.Sms.Inbox.DATE)

                var count = 0
                while (cursor.moveToNext() && count < maxMessages) {
                    val smsId = if (idIndex >= 0) cursor.getLong(idIndex) else count.toLong()
                    val sender = if (addressIndex >= 0) cursor.getString(addressIndex) ?: "Unknown" else "Unknown"
                    val body = if (bodyIndex >= 0) cursor.getString(bodyIndex) ?: "" else ""
                    val date = if (dateIndex >= 0) cursor.getLong(dateIndex) else System.currentTimeMillis()

                    val strictParsed = SmsParser.parse(body, sender, date)
                    val isFinancial = strictParsed != null || SmsParser.isFinancialCandidate(body, sender)
                    val preview = strictParsed ?: if (isFinancial) SmsParser.parseLenient(body, sender, date) else null

                    // Check if already synced in Room DB by exact rawSms match, ref match, or timestamp+amount match
                    val matchedTx = existingTransactions.firstOrNull { tx ->
                        (tx.rawSms != null && tx.rawSms == body) ||
                        (!preview?.vpaOrRef.isNullOrBlank() && tx.vpaOrRef == preview?.vpaOrRef) ||
                        (preview != null && preview.amount > 0 && tx.amount == preview.amount && abs(tx.timestamp - date) < 180_000L)
                    }

                    result.add(
                        RawSmsItem(
                            id = smsId,
                            sender = sender,
                            body = body,
                            timestamp = date,
                            isSynced = matchedTx != null,
                            isFinancialCandidate = isFinancial,
                            parsedPreview = preview,
                            syncedTransactionId = matchedTx?.id
                        )
                    )
                    count++
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        result
    }
}
