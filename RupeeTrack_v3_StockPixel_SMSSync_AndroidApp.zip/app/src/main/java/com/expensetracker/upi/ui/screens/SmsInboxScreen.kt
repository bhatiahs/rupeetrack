package com.expensetracker.upi.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.expensetracker.upi.model.RawSmsItem
import com.expensetracker.upi.model.pixelGroupItemShape
import java.text.SimpleDateFormat
import java.util.*

enum class SmsFilterMode(val label: String) {
    ALL_FINANCIAL("Bank & UPI"),
    UNSYNCED("Not Synced"),
    SYNCED("Synced"),
    ALL_MESSAGES("All SMS")
}

@Composable
fun SmsInboxScreen(
    smsList: List<RawSmsItem>,
    hasSmsPermission: Boolean,
    isLoading: Boolean,
    onRequestPermission: () -> Unit,
    onRefreshInbox: () -> Unit,
    onSyncSmsClick: (RawSmsItem) -> Unit,
    onQuickSyncSms: (RawSmsItem) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf(SmsFilterMode.ALL_FINANCIAL) }
    var searchQuery by remember { mutableStateOf("") }

    val filteredSms = remember(smsList, selectedFilter, searchQuery) {
        smsList.filter { item ->
            val matchesFilter = when (selectedFilter) {
                SmsFilterMode.ALL_FINANCIAL -> item.isFinancialCandidate || item.isSynced
                SmsFilterMode.UNSYNCED -> !item.isSynced && item.isFinancialCandidate
                SmsFilterMode.SYNCED -> item.isSynced
                SmsFilterMode.ALL_MESSAGES -> true
            }
            val matchesSearch = searchQuery.isBlank() ||
                    item.body.contains(searchQuery, ignoreCase = true) ||
                    item.sender.contains(searchQuery, ignoreCase = true)
            matchesFilter && matchesSearch
        }
    }

    val syncedCount = smsList.count { it.isSynced }
    val unsyncedCount = smsList.count { !it.isSynced && it.isFinancialCandidate }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        // Stock Google Messages Top Header & Search Bar
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SMS Sync Center",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "$syncedCount Synced • $unsyncedCount Unsynced Bank SMS",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                FilledTonalIconButton(onClick = onRefreshInbox) {
                    if (isLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh SMS")
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Pixel Pill Search Bar (like Google Messages / Gmail)
        item {
            TextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search SMS messages or bank senders...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Filter Chips Row
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(SmsFilterMode.entries.size) { index ->
                    val mode = SmsFilterMode.entries[index]
                    FilterChip(
                        selected = selectedFilter == mode,
                        onClick = { selectedFilter = mode },
                        label = { Text(mode.label) },
                        leadingIcon = if (selectedFilter == mode) {
                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        } else null,
                        shape = RoundedCornerShape(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        if (!hasSmsPermission) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "SMS Permission Required",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Grant SMS read permission to inspect your messages and manually sync missed UPI transactions.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = onRequestPermission) {
                            Text("Grant Permission")
                        }
                    }
                }
            }
        } else if (filteredSms.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isLoading) "Reading SMS Inbox..." else "No matching SMS messages found.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            itemsIndexed(filteredSms) { index, sms ->
                val itemShape = pixelGroupItemShape(index, filteredSms.size)
                SmsInspectorCard(
                    sms = sms,
                    shape = itemShape,
                    onEditAndSync = { onSyncSmsClick(sms) },
                    onQuickSync = { onQuickSyncSms(sms) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp))
        }
    }
}

@Composable
fun SmsInspectorCard(
    sms: RawSmsItem,
    shape: RoundedCornerShape,
    onEditAndSync: () -> Unit,
    onQuickSync: () -> Unit
) {
    val dateFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
    val syncedGreen = Color(0xFF2E7D32)
    val unsyncedAmber = Color(0xFFE65100)

    val containerColor = when {
        sms.isSynced -> syncedGreen.copy(alpha = 0.08f)
        sms.isFinancialCandidate -> MaterialTheme.colorScheme.surfaceContainerLow
        else -> MaterialTheme.colorScheme.surfaceContainerLowest
    }

    val borderModifier = if (sms.isSynced) {
        Modifier.border(1.dp, syncedGreen.copy(alpha = 0.3f), shape)
    } else if (sms.isFinancialCandidate) {
        Modifier.border(1.dp, unsyncedAmber.copy(alpha = 0.28f), shape)
    } else {
        Modifier
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .then(borderModifier),
        shape = shape,
        color = containerColor
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Row: Avatar + Sender + Date + Sync Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (sms.isSynced) syncedGreen.copy(alpha = 0.2f)
                                else MaterialTheme.colorScheme.primaryContainer
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (sms.isSynced) Icons.Default.CheckCircle else Icons.Default.Sms,
                            contentDescription = null,
                            tint = if (sms.isSynced) syncedGreen else MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = sms.sender,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = dateFormat.format(Date(sms.timestamp)),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Highlight Badge: Synced vs Not Synced
                if (sms.isSynced) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = syncedGreen.copy(alpha = 0.18f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.DoneAll,
                                contentDescription = null,
                                tint = syncedGreen,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Synced",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = syncedGreen
                            )
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = unsyncedAmber.copy(alpha = 0.15f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = unsyncedAmber,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Not Synced",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = unsyncedAmber
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // SMS Message Body
            Text(
                text = sms.body,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                lineHeight = 18.sp
            )

            // Detected Preview & Action Buttons for Unsynced SMS
            if (!sms.isSynced) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val previewAmt = sms.parsedPreview?.amount
                    if (previewAmt != null && previewAmt > 0) {
                        Text(
                            text = "Detected: ₹${"%.0f".format(previewAmt)} • ${sms.parsedPreview.merchant}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    } else {
                        Text(
                            text = "Tap to extract & log spend",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (previewAmt != null && previewAmt > 0) {
                            FilledTonalButton(
                                onClick = onQuickSync,
                                shape = RoundedCornerShape(16.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Quick Sync", fontSize = 12.sp)
                            }
                        }
                        Button(
                            onClick = onEditAndSync,
                            shape = RoundedCornerShape(16.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Review & Sync", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
