package com.expensetracker.upi.sms

import com.expensetracker.upi.model.ExpenseCategory
import com.expensetracker.upi.model.ParsedTransaction
import com.expensetracker.upi.model.PaymentMode
import com.expensetracker.upi.model.TransactionType
import java.util.regex.Pattern

object SmsParser {

    // Comprehensive Indian currency & bank debit amount patterns:
    // 1. Rs. 500, INR 1,200.50, ₹450
    // 2. 500 Rs, 450 INR
    // 3. SBI/PNB format: "debited by 450.0", "debited for 1200.00", "paid 250"
    private val amountPatterns = listOf(
        Pattern.compile("""(?:rs\.?|inr|₹|mrp)\s*([\d,]+(?:\.\d{1,2})?)""", Pattern.CASE_INSENSITIVE),
        Pattern.compile("""([\d,]+(?:\.\d{1,2})?)\s*(?:rs\.?|inr|₹)""", Pattern.CASE_INSENSITIVE),
        Pattern.compile("""(?:debited|deducted|paid|spent|sent|trf|transferred|withdrawn|charged)\s+(?:by|with|for|of|amount)?\s*(?:rs\.?|inr|₹)?\s*([\d,]+(?:\.\d{1,2})?)""", Pattern.CASE_INSENSITIVE)
    )

    private val fallbackNumberPattern = Pattern.compile("""\b(\d{1,6}(?:,\d{2,3})*(?:\.\d{1,2})?)\b""")

    // Broad debit indicators covering all major Indian banks & UPI apps
    private val debitKeywords = listOf(
        "debited", "deducted", "paid", "spent", "sent",
        "trf to", "transfer to", "transferred", "withdrawn", "charged",
        "purchase", "sent to", "paid to", "dr from", "vpa"
    )

    private val creditKeywords = listOf(
        "credited", "received", "refunded", "cashback", "deposited", "added to"
    )

    // False-positive phrases: bill reminders, due notices, OTPs, promotional alerts
    private val ignorePatterns = listOf(
        """\bdue\s+date\b""",
        """\bdue\s+on\b""",
        """\bis\s+due\b""",
        """\bbill\s+(?:is\s+)?generated\b""",
        """\bbill\s+of\s+(?:rs\.?|inr|₹)\b""",
        """\bmin(?:imum)?\s+amount\s+due\b""",
        """\btotal\s+amount\s+due\b""",
        """\bpay\s+before\b""",
        """\bpay\s+by\b""",
        """\bpay\s+now\b""",
        """\bpayment\s+reminder\b""",
        """\bbill\s+reminder\b""",
        """\breminder:?\b""",
        """\botp\b""",
        """\bone\s*time\s*password\b""",
        """\bverification\s*code\b""",
        """\bdo\s+not\s+share\b""",
        """\bcollect\s+request\b""",
        """\bhas\s+requested\b""",
        """\bpre-?approved\b""",
        """\bapply\s+now\b"""
    ).map { Pattern.compile(it, Pattern.CASE_INSENSITIVE) }

    // Bank / UPI Ref regex (handles Refno, UPI:, UTR, Ref No)
    private val refPattern = Pattern.compile(
        """(?:ref\s*(?:no\.?)?|utr|txn\s*id|upi\s*(?:ref(?:\s*no\.?)?)?)\s*[:\-]?\s*([A-Za-z0-9]{6,})""",
        Pattern.CASE_INSENSITIVE
    )

    // VPA / UPI ID pattern: user@upi, shop@okhdfcbank, name@ybl
    private val vpaPattern = Pattern.compile(
        """([a-zA-Z0-9.\-_]+@[a-zA-Z0-9]+)""",
        Pattern.CASE_INSENSITIVE
    )

    // Payee / Merchant extraction patterns (handles SBI 'trf to', ICICI '; MERCHANT credited', HDFC 'to VPA')
    private val merchantPatterns = listOf(
        Pattern.compile("""(?:trf\s+to|transfer\s+to|to\s+vpa|paid\s+to|sent\s+to|towards|to|at)\s+([A-Za-z0-9\s&.'\-@]{2,30}?)(?:\s+on|\s+ref|\s+upi|\s+avl|\s+bal|\s+dated|;|\.|,|\(|$)""", Pattern.CASE_INSENSITIVE),
        Pattern.compile("""(?:;|,)\s*([A-Za-z0-9\s&.'\-]{2,30}?)\s+credited""", Pattern.CASE_INSENSITIVE)
    )

    // Account ending pattern: A/c XX1234, Acct XX123, Card ending 1234
    private val accountPattern = Pattern.compile(
        """(?:a/c|acct|account|card|ending|xx|\*\*)\s*(?:no\.?\s*)?([xX*]*\d{3,4})""",
        Pattern.CASE_INSENSITIVE
    )

    fun isFinancialCandidate(smsBody: String, sender: String): Boolean {
        val lower = smsBody.lowercase()
        val hasMoneyWord = lower.contains("rs") || lower.contains("inr") || lower.contains("₹") ||
                lower.contains("debited") || lower.contains("credited") || lower.contains("upi") ||
                lower.contains("vpa") || lower.contains("paid") || lower.contains("spent") ||
                lower.contains("a/c") || lower.contains("acct")
        return hasMoneyWord
    }

    fun parse(smsBody: String, sender: String, timestamp: Long = System.currentTimeMillis()): ParsedTransaction? {
        val lowerText = smsBody.lowercase()

        // 1. Filter out OTPs and verification messages immediately
        if (lowerText.contains("otp") || lowerText.contains("verification code") || lowerText.contains("one time password")) {
            return null
        }

        // 2. Filter out bill reminders and due notices
        val isBillReminder = ignorePatterns.any { it.matcher(smsBody).find() }
        val hasExplicitAccountDebit = lowerText.contains("debited") || lowerText.contains("deducted") || lowerText.contains("trf to")

        if (isBillReminder && !hasExplicitAccountDebit) {
            return null
        }

        // 3. Determine Debit vs Credit
        // Note: ICICI UPI debit SMS says "Acct XX123 debited for Rs 500; MERCHANT credited".
        // So if "debited" is present, it is a DEBIT unless it specifically says "credited to your a/c"
        val hasDebit = debitKeywords.any { lowerText.contains(it) }
        val hasCredit = creditKeywords.any { lowerText.contains(it) }

        if (!hasDebit && !hasCredit) return null

        val isAccountCredit = (lowerText.contains("credited to") || lowerText.contains("credited in") || lowerText.contains("credited with") || lowerText.contains("credited by")) && !lowerText.contains("debited")
        val type = if (isAccountCredit) TransactionType.CREDIT else TransactionType.DEBIT

        // 4. Extract Amount
        var amount: Double? = null
        for (pattern in amountPatterns) {
            val matcher = pattern.matcher(smsBody)
            if (matcher.find()) {
                val amtStr = matcher.group(1)?.replace(",", "")
                val parsedAmt = amtStr?.toDoubleOrNull()
                if (parsedAmt != null && parsedAmt > 0.0) {
                    amount = parsedAmt
                    break
                }
            }
        }
        if (amount == null || amount <= 0.0) return null

        return buildTransaction(amount, type, smsBody, sender, timestamp)
    }

    /**
     * Lenient parser used when the user manually taps "Sync / Add" on any SMS in the SMS Sync Tab.
     * Extracts the best available amount and merchant even if the bank used a non-standard SMS template.
     */
    fun parseLenient(smsBody: String, sender: String, timestamp: Long = System.currentTimeMillis()): ParsedTransaction {
        // First try strict parse
        parse(smsBody, sender, timestamp)?.let { return it }

        // Fallback: try amount patterns
        var amount: Double? = null
        for (pattern in amountPatterns) {
            val matcher = pattern.matcher(smsBody)
            if (matcher.find()) {
                amount = matcher.group(1)?.replace(",", "")?.toDoubleOrNull()
                if (amount != null && amount > 0.0) break
            }
        }

        // Fallback to any reasonable decimal/number in the SMS
        if (amount == null || amount <= 0.0) {
            val m = fallbackNumberPattern.matcher(smsBody)
            while (m.find()) {
                val candidate = m.group(1)?.replace(",", "")?.toDoubleOrNull()
                if (candidate != null && candidate > 0.0 && candidate < 1000000.0) {
                    amount = candidate
                    break
                }
            }
        }

        val finalAmount = amount ?: 0.0
        val lowerText = smsBody.lowercase()
        val type = if (lowerText.contains("credited") && !lowerText.contains("debited")) {
            TransactionType.CREDIT
        } else {
            TransactionType.DEBIT
        }

        return buildTransaction(finalAmount, type, smsBody, sender, timestamp)
    }

    private fun buildTransaction(
        amount: Double,
        type: TransactionType,
        smsBody: String,
        sender: String,
        timestamp: Long
    ): ParsedTransaction {
        val lowerText = smsBody.lowercase()

        val refMatcher = refPattern.matcher(smsBody)
        val refNo = if (refMatcher.find()) refMatcher.group(1) else null

        val vpaMatcher = vpaPattern.matcher(smsBody)
        val vpa = if (vpaMatcher.find()) vpaMatcher.group(1) else null

        var merchant: String? = null
        for (pattern in merchantPatterns) {
            val m = pattern.matcher(smsBody)
            if (m.find()) {
                val candidate = m.group(1)?.trim()
                if (!candidate.isNullOrBlank() &&
                    !candidate.equals("vpa", ignoreCase = true) &&
                    !candidate.equals("upi", ignoreCase = true) &&
                    !candidate.equals("a/c", ignoreCase = true) &&
                    candidate.length > 1
                ) {
                    merchant = candidate
                    break
                }
            }
        }

        if (merchant.isNullOrBlank()) {
            merchant = vpa ?: sender.replace(Regex("""^[A-Za-z]{2}-"""), "").ifBlank { "UPI Spend" }
        }

        merchant = merchant.replace(Regex("""(?i)\bvia\s+(phonepe|google\s*pay|gpay|paytm|cred|bhim|upi)\b"""), "").trim()
        merchant = merchant.replace(Regex("""(?i)\b(upi|ref|refno|bal|avl|on|dated|dr|cr)\b"""), "").trim()
        if (merchant.isBlank()) merchant = "UPI Spend"

        val accMatcher = accountPattern.matcher(smsBody)
        val account = if (accMatcher.find()) accMatcher.group(1) else null

        val mode = when {
            lowerText.contains("upi") || vpa != null || lowerText.contains("vpa") -> PaymentMode.UPI
            lowerText.contains("card") || lowerText.contains("pos") -> PaymentMode.CARD
            lowerText.contains("netbanking") || lowerText.contains("neft") || lowerText.contains("imps") -> PaymentMode.NET_BANKING
            else -> PaymentMode.UPI
        }

        val category = CategoryClassifier.classify(merchant, smsBody, vpa)

        return ParsedTransaction(
            amount = amount,
            type = type,
            merchant = merchant.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() },
            category = category,
            paymentMode = mode,
            vpaOrRef = refNo ?: vpa,
            accountInfo = account,
            date = timestamp,
            rawSms = smsBody,
            sender = sender
        )
    }
}
