package com.expensetracker.upi.model

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

enum class TransactionType {
    DEBIT,
    CREDIT
}

enum class PaymentMode(val label: String) {
    UPI("UPI"),
    CARD("Card"),
    NET_BANKING("NetBanking"),
    CASH("Cash"),
    OTHER("Other")
}

enum class ExpenseCategory(
    val displayName: String,
    val icon: ImageVector,
    val color: Color
) {
    FOOD_DINING("Food & Dining", Icons.Default.Restaurant, Color(0xFFEF5350)),
    GROCERY("Groceries", Icons.Default.LocalGroceryStore, Color(0xFF4CAF50)),
    SHOPPING("Shopping", Icons.Default.ShoppingBag, Color(0xFFFF9800)),
    TRAVEL_COMMUTE("Travel & Fuel", Icons.Default.DirectionsCar, Color(0xFF03A9F4)),
    BILLS_UTILITIES("Bills & Utilities", Icons.Default.ReceiptLong, Color(0xFF9C27B0)),
    ENTERTAINMENT("Entertainment", Icons.Default.Movie, Color(0xFFE91E63)),
    HEALTH_WELLNESS("Health & Medical", Icons.Default.MedicalServices, Color(0xFF009688)),
    INVESTMENT_TRANSFER("Investments", Icons.Default.AccountBalance, Color(0xFF3F51B5)),
    UNCATEGORIZED("General UPI", Icons.Default.Payments, Color(0xFF607D8B));

    companion object {
        fun fromString(value: String): ExpenseCategory {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: UNCATEGORIZED
        }
    }
}

data class ParsedTransaction(
    val amount: Double,
    val type: TransactionType,
    val merchant: String,
    val category: ExpenseCategory,
    val paymentMode: PaymentMode = PaymentMode.UPI,
    val vpaOrRef: String? = null,
    val accountInfo: String? = null,
    val date: Long = System.currentTimeMillis(),
    val rawSms: String,
    val sender: String
)

data class RawSmsItem(
    val id: Long,
    val sender: String,
    val body: String,
    val timestamp: Long,
    val isSynced: Boolean,
    val isFinancialCandidate: Boolean,
    val parsedPreview: ParsedTransaction? = null,
    val syncedTransactionId: Long? = null
)

data class RuplyCard(
    val id: String,
    val name: String,
    val bank: String,
    val last4: String,
    val totalSpentThisMonth: Double,
    val gradientColors: List<Color>
)

data class SplitEntry(
    val id: Long = 0,
    val personName: String,
    val amount: Double,
    val isOwedToMe: Boolean,
    val note: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Stock Google Pixel (Android 15/16) Segmented List Item Corner Geometry.
 * Outer items have 24.dp corners; adjacent inner edges have 6.dp corners with 2.dp vertical spacing.
 */
fun pixelGroupItemShape(index: Int, totalCount: Int): RoundedCornerShape {
    if (totalCount <= 1) return RoundedCornerShape(24.dp)
    return when (index) {
        0 -> RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp, bottomStart = 6.dp, bottomEnd = 6.dp)
        totalCount - 1 -> RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp, bottomStart = 24.dp, bottomEnd = 24.dp)
        else -> RoundedCornerShape(6.dp)
    }
}
