package com.expensetracker.upi.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.expensetracker.upi.model.ExpenseCategory
import com.expensetracker.upi.model.PaymentMode
import com.expensetracker.upi.model.TransactionType

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val amount: Double,
    val type: TransactionType,
    val category: ExpenseCategory,
    val merchant: String,
    val paymentMode: PaymentMode = PaymentMode.UPI,
    val vpaOrRef: String? = null,
    val accountInfo: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val rawSms: String? = null,
    val sender: String? = null,
    val isAutomated: Boolean = true
)
