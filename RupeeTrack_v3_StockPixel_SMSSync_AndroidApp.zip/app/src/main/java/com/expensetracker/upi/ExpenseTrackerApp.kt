package com.expensetracker.upi

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.expensetracker.upi.data.AppDatabase
import com.expensetracker.upi.data.TransactionRepository

class ExpenseTrackerApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var repository: TransactionRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = AppDatabase.getDatabase(this)
        repository = TransactionRepository(database.transactionDao())

        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID_EXPENSES,
                "UPI Expense Alerts",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifies when a new UPI transaction is detected and auto-categorized."
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID_EXPENSES = "upi_expense_alerts"
        lateinit var instance: ExpenseTrackerApp
            private set
    }
}
