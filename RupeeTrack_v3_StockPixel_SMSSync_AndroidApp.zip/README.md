# RupeeTrack — UPI & SMS Expense Tracker for Android

A modern, privacy-focused native Android expense tracking app built with **Kotlin**, **Jetpack Compose (Material 3 Dynamic Color / Pixel Theme)**, and **Room Database**.

RupeeTrack runs completely on-device with **zero cloud uploads**, reading bank and UPI SMS notifications to automatically parse, record, and intelligently categorize your transactions in Indian Rupees (**₹ INR**).

---

## Key Features

1. **Automatic UPI & Bank SMS Detection**:
   - Captures real-time incoming SMS via BroadcastReceiver (`RECEIVE_SMS`).
   - One-tap historical inbox scanner (`READ_SMS`) to import the last 30/60 days of spending.
   - Built-in regex engine engineered specifically for Indian bank and payment formats (SBI, HDFC, ICICI, Axis, Kotak, PNB, PhonePe, Google Pay, Paytm, BHIM, CRED).
   - Extracts: Amount in ₹ INR, Merchant/Payee, VPA/UPI ID, Ref/UTR number, and Account digits.

2. **Intelligent On-Device Categorization**:
   - Keyword & VPA rule classifier with instant mapping into:
     - 🍔 **Food & Dining** (Swiggy, Zomato, Starbucks, McDonald's, cafes, restaurants)
     - 🛒 **Groceries & Daily** (Blinkit, Zepto, Instamart, BigBasket, DMart, Kirana)
     - 🛍️ **Shopping & E-Commerce** (Amazon, Flipkart, Myntra, Ajio, Nykaa)
     - 🚗 **Travel & Fuel** (Uber, Ola, Rapido, IRCTC, Petrol/Fuel pumps, Fastag)
     - 💡 **Bills & Utilities** (Electricity, Gas, Airtel, Jio, Broadband)
     - 🎬 **Entertainment & Subscriptions** (Netflix, Spotify, BookMyShow, PVR)
     - 💊 **Health & Medical** (Apollo, 1mg, PharmEasy, Clinics, Cult.fit)
     - 🏦 **Transfers & Self** (Mutual funds, Zerodha, Groww, deposits)
     - 💳 **General UPI**

3. **Pixel Material You UI**:
   - Full Material 3 system with **Dynamic Colors** (`dynamicLightColorScheme` and `dynamicDarkColorScheme`) matching Android 12+ wallpaper palettes.
   - Rounded 28.dp cards, tonal elevation, expressive typography, and search bar.
   - Live spending progress bars and category breakdown percentages.

4. **100% Offline & Private (Room SQLite)**:
   - All financial data is stored locally in an encrypted/private SQLite database using Android Jetpack Room.
   - Deduplication engine prevents double entries from repeated SMS or OTP triggers.

---

## Project Structure

```
ExpenseTrackerUPI/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── java/com/expensetracker/upi/
│   │       │   ├── data/                 # Room Entities, DAOs, Database & Repository
│   │       │   │   ├── AppDatabase.kt
│   │       │   │   ├── Converters.kt
│   │       │   │   ├── TransactionDao.kt
│   │       │   │   ├── TransactionEntity.kt
│   │       │   │   └── TransactionRepository.kt
│   │       │   ├── model/                # Domain models, Enums, Categories
│   │       │   │   └── Models.kt
│   │       │   ├── receiver/             # BroadcastReceiver for real-time incoming SMS
│   │       │   │   └── SmsReceiver.kt
│   │       │   ├── sms/                  # SMS Regex Parser & Categorization Engine
│   │       │   │   ├── CategoryClassifier.kt
│   │       │   │   ├── SmsInboxScanner.kt
│   │       │   │   └── SmsParser.kt
│   │       │   ├── ui/
│   │       │   │   ├── components/       # Pixel Transaction Items & Cards
│   │       │   │   ├── dialogs/          # Add Manual Spend & Detail Dialogs
│   │       │   │   ├── screens/          # Dashboard, Spends List, Analytics
│   │       │   │   └── theme/            # Material You Dynamic Color & Typography
│   │       │   ├── viewmodel/            # Jetpack ViewModel & StateFlow
│   │       │   ├── ExpenseTrackerApp.kt
│   │       │   └── MainActivity.kt
│   │       ├── res/
│   │       └── AndroidManifest.xml
│   └── build.gradle.kts
├── gradle/
│   └── libs.versions.toml                # Dependency version catalog
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

---

## How to Build & Run in Android Studio

1. Unzip `ExpenseTrackerUPI_AndroidApp.zip`.
2. Open Android Studio (Ladybug, Koala, Jellyfish, Iguana, or newer).
3. Select **File > Open** and choose the `ExpenseTrackerUPI` folder.
4. Let Gradle sync project dependencies.
5. Connect your Android phone or start an Android Emulator (API 31+ recommended for Dynamic Color).
6. Click **Run (Shift + F10)**.
7. Upon opening, tap **"Enable"** on the SMS banner to grant SMS permissions and tap the sync button to import your recent UPI transactions.

---

## How to Build the APK Without a Laptop (Free Cloud Build via GitHub Actions)

If you don't have a laptop or Android Studio installed, you can compile and download the installable `.apk` file directly on your phone using GitHub's free cloud servers:

1. **Create a Free GitHub Account**: Open [github.com](https://github.com) on your mobile browser.
2. **Create a New Repository**: Tap **+ > New repository**, name it `rupeetrack`, make it Private or Public, and tap **Create repository**.
3. **Upload the Project Files**:
   - Tap **uploading an existing file** on the setup page.
   - Extract `ExpenseTrackerUPI_AndroidApp.zip` on your phone (using your phone's Files app).
   - Select and upload all project files (especially ensuring the `.github` folder is included) and tap **Commit changes**.
4. **Automatic Cloud Build**:
   - Because the project includes `.github/workflows/build_apk.yml`, GitHub automatically triggers a cloud runner with Java 17 and Android SDK to compile the APK.
   - Go to the **Actions** tab in your repository to watch the build progress (takes about 2–3 minutes).
5. **Download the APK to Your Phone**:
   - Once the build succeeds with a green checkmark, tap into the run named **"Build RupeeTrack APK"**.
   - Scroll down to the **Artifacts** section at the bottom.
   - Tap **`RupeeTrack-Debug-APK`** to download the compiled `.apk` file directly to your phone.
6. **Install on Android**:
   - Open your phone's Downloads folder, tap the APK, allow installation from your browser/files app, and launch **RupeeTrack**!
